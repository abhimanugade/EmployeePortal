import React from 'react';

const AdminHome = () => {
    return (
        <>
        <div className="homepage mt-4">
        <h1 className="text-center ">welcome</h1> 
        </div>
          
        </>
    )
};

export default AdminHome;
