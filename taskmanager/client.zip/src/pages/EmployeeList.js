import React from 'react';
import AdminNavbar from  "../AdminNavbar";
import Footer from "../Footer"
import EmployeeDetails from "../EmployeeDetails";


const EmployeeList = () => {

  return (
  <>
     <AdminNavbar/>
     <EmployeeDetails/>
   
  </>
  )
  ;
};

export default EmployeeList;
