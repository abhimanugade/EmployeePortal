import React from 'react';
import AdminNavbar from  "../AdminNavbar";
import Footer from "../Footer";
import TimeBookingData from "../TimeBookingData";

const TimeBookingList = () => {
  return (
  <>
     <AdminNavbar/>
     <TimeBookingData/>
    
  </>
  );
};

export default TimeBookingList;
