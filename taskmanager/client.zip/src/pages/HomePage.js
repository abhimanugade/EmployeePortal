import React from 'react';
import Home from "../Home";
import Navbar from  "../Navbar";
import Footer from "../Footer"

const HomePage = () => {
    return (
        <>
            <Navbar/>
            <Home/>
            
        </>
    )
}

export default HomePage
