import React from 'react';
import TaskDetails from "../TaskDetails";
import Navbar from  "../Navbar";
import Footer from "../Footer"


const AddTaskDetails = () => {
    return (
        <>
           <Navbar/>
           <TaskDetails/>  
         
        </>
    )  
}

export default AddTaskDetails
