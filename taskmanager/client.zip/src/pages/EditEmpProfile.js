import React from 'react';
import Navbar from  "../Navbar";
import EditProfile from  "../EditProfile";
import Footer from "../Footer"

const EditEmpProfile = () => {
    return (
        <>
             <Navbar/>
            <EditProfile/>
           
        </>
    )
}

export default EditEmpProfile
