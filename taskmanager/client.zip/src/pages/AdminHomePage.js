import React from 'react';
import AdminNavbar from  "../AdminNavbar";
import AdminHome from "../AdminHome";

import Footer from "../Footer"

const AdminHomePage = () => {
  return <>
  <AdminNavbar/>
  <AdminHome/>
   
  
  </>;
};

export default AdminHomePage;
