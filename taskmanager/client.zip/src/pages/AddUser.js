import React from 'react'
import UserMaster from '../UserMaster'

const AddUser = () => {
    return (
        <>
            <UserMaster/>
        </>
    )
}

export default AddUser
