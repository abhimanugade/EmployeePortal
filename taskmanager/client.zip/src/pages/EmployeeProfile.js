import React from 'react';
import Navbar from  "../Navbar";
import Profile from  "../Profile";
import Footer from "../Footer"

const EmployeeProfile = () => {
    return (
        <>
            <Navbar/>
            <Profile/>
         
        </>
    )
}

export default EmployeeProfile
