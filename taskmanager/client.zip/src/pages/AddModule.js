import React from 'react';
import Module from "../Module";
import AdminNavbar from  "../AdminNavbar";
import Footer from "../Footer"

const AddModule = () => {
  return <>
  <AdminNavbar/>
  <Module/>
 
  </>;
};

export default AddModule;
