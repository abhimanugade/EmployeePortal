import React from 'react';
import AdminNavbar from  "../AdminNavbar";
import Footer from "../Footer";
import AssignLeave from "../AssignLeave";

const AssignLeavePage = () => {
  return (<>
       <AdminNavbar/>
     <AssignLeave/>
    
  </>
  );
};

export default AssignLeavePage;
