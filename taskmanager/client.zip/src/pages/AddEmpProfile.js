import React from 'react'
import Navbar from  "../Navbar";
import AddProfile from  "../AddProfile";
const AddEmpProfile = () => {
    return (
        <>
            <Navbar/>
            <AddProfile/>
        </>
    )
}

export default AddEmpProfile
