import React from 'react';
import LeavesDetails from "../LeavesDetails";
import Navbar from  "../Navbar";
import Footer from "../Footer"

const AddLeaveDetails = () => {
    return (
        <>
            <Navbar/>
           <LeavesDetails/> 
          
           
        </>
    )
}

export default AddLeaveDetails
