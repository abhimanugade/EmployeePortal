import React from "react";

const Footer = () => {
  return (
    <>
       <footer className="footer"> 
               <div className="container">
                   <div className="row p-0">
                        <div className="">
                            <p className="text-center">copyright @2022  Rejuvenation Technologies.All rights reserved</p>
                        </div>

                   </div>
                       
                   </div>
              
           </footer> 

      
    </>
  );
};

export default Footer;
