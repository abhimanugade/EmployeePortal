import React from 'react'

const Home = () => {
    return (
        <>
        <div className="homepage mt-3">
        <h1 className="text-center">welcome</h1> 
        </div>
          
        </>
    )
}

export default Home
